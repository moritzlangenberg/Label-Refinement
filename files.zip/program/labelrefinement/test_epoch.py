import egraph_builder
import mapping_all
import egraph_label_refinement
import precision_util
from time import time
import mapping_modularity
from scipy import stats


def run(event_log, xixi_log, original_event_log, original_net, original_initial_marking, original_final_marking, parameters={"TIMESTAMP_KEY": "no_timestamp", "ACTIVITY_KEY": "concept:name",
        "EVENT_IDENTIFICATION": "Activity", "CASE_ID_KEY": 0, "LIFECYCLE_KEY": "lifecycle:transition",
                    "LIFECYCLE_MODE": "atomic", "k": 1}, weight_matched=1, weight_not_matched=10, weight_structure=1, k=1, basic_cost=1,
                                        labeling_function=egraph_label_refinement.default_labeling_function, use_adaptive_parameters=False):

    start_time = time()
    egraphs, map_egraph_ID_to_trace_IDs, map_trace_ID_to_egraph_ID                          = egraph_builder.get_egraphs(parameters, False, event_log)

    time_s = time()
    egraphs_folding, map_egraph_ID_to_trace_IDs_folding, map_trace_ID_to_egraph_ID_folding  = egraph_builder.get_egraphs(parameters, True, event_log)
    time_e = time()
    time0 = time_e - time_s

    time_s = time()
    mapping              = mapping_all.get_mappings(egraphs, weight_matched, weight_not_matched, weight_structure, k, basic_cost, labeling_function, "GREEDY", False)
    time_e = time()
    time_for_greedy_mapping = time_e - time_s

    mapping_folding      = mapping_all.get_mappings(egraphs_folding, weight_matched, weight_not_matched, weight_structure, k, basic_cost, labeling_function, "GREEDY", False)

    time_s = time()
    mapping_semi         = mapping_all.get_mappings(egraphs, weight_matched, weight_not_matched, weight_structure, k, basic_cost, labeling_function, "SEMI_GREEDY", False)
    time_e = time()
    time_for_semi_greedy_mapping = time_e - time_s

    time_s = time()
    mapping_folding_semi = mapping_all.get_mappings(egraphs_folding, weight_matched, weight_not_matched, weight_structure, k, basic_cost, labeling_function, "SEMI_GREEDY", False)
    time_e = time()
    time1 = time_e - time_s

    mapping_quality = mapping_modularity.get_mapping_modularity(event_log, egraphs, map_egraph_ID_to_trace_IDs, map_trace_ID_to_egraph_ID, mapping, labeling_function)
    mapping_folding_quality = mapping_modularity.get_mapping_modularity(event_log, egraphs_folding, map_egraph_ID_to_trace_IDs_folding, map_trace_ID_to_egraph_ID_folding, mapping_folding, labeling_function)
    mapping_semi_quality = mapping_modularity.get_mapping_modularity(event_log, egraphs, map_egraph_ID_to_trace_IDs, map_trace_ID_to_egraph_ID, mapping_semi, labeling_function)
    mapping_folding_semi_quality = mapping_modularity.get_mapping_modularity(event_log, egraphs_folding, map_egraph_ID_to_trace_IDs_folding, map_trace_ID_to_egraph_ID_folding, mapping_folding_semi, labeling_function)
    #print(mapping_quality)
    #print(mapping_folding_quality)
    #print(mapping_semi_quality)
    #print(mapping_folding_semi_quality)


    ref_log, imprecise_labels, original_labels, num_of_new_labels = egraph_label_refinement.get_refined_event_log(event_log, cluster_method="CONNECTED_COMPONENTS", detection_mode_imp_in_loop="vertical", egraphs=egraphs, mapping=mapping, map_egraph_ID_to_trace_IDs=map_egraph_ID_to_trace_IDs, map_trace_ID_to_egraph_ID=map_trace_ID_to_egraph_ID, use_adaptive_parameters=use_adaptive_parameters)
    ref_log_comdec, _, _, num_of_new_labels_comdec = egraph_label_refinement.get_refined_event_log(event_log, egraphs=egraphs, cluster_method="COMMUNITY_DETECTION", detection_mode_imp_in_loop="vertical", mapping=mapping, map_egraph_ID_to_trace_IDs=map_egraph_ID_to_trace_IDs, map_trace_ID_to_egraph_ID=map_trace_ID_to_egraph_ID, use_adaptive_parameters=use_adaptive_parameters)
    ref_log_folding, _, _, num_of_new_labels_folding = egraph_label_refinement.get_refined_event_log(event_log, cluster_method="CONNECTED_COMPONENTS", detection_mode_imp_in_loop="vertical", egraphs=egraphs_folding, mapping=mapping_folding, map_egraph_ID_to_trace_IDs=map_egraph_ID_to_trace_IDs_folding, map_trace_ID_to_egraph_ID=map_trace_ID_to_egraph_ID_folding, use_adaptive_parameters=use_adaptive_parameters)
    ref_log_semi, _, _, num_of_new_labels_semi = egraph_label_refinement.get_refined_event_log(event_log, cluster_method="CONNECTED_COMPONENTS", detection_mode_imp_in_loop="vertical", egraphs=egraphs, mapping=mapping_semi, map_egraph_ID_to_trace_IDs=map_egraph_ID_to_trace_IDs, map_trace_ID_to_egraph_ID=map_trace_ID_to_egraph_ID, use_adaptive_parameters=use_adaptive_parameters)
    ref_log_no_vertical, _, _, num_of_new_labels_no_vertical = egraph_label_refinement.get_refined_event_log(event_log, cluster_method="CONNECTED_COMPONENTS", detection_mode_imp_in_loop="postprocessing", egraphs=egraphs, mapping=mapping, map_egraph_ID_to_trace_IDs=map_egraph_ID_to_trace_IDs, map_trace_ID_to_egraph_ID=map_trace_ID_to_egraph_ID, use_adaptive_parameters=use_adaptive_parameters)

    #print(num_of_new_labels, num_of_new_labels_comdec, num_of_new_labels_folding, num_of_new_labels_semi, num_of_new_labels_no_vertical)

    time_s = time()
    ref_log_all, _, _, _ = egraph_label_refinement.get_refined_event_log(event_log, cluster_method="COMMUNITY_DETECTION", detection_mode_imp_in_loop="postprocessing", egraphs=egraphs_folding, mapping=mapping_folding_semi, map_egraph_ID_to_trace_IDs=map_egraph_ID_to_trace_IDs_folding, map_trace_ID_to_egraph_ID=map_trace_ID_to_egraph_ID_folding, use_adaptive_parameters=use_adaptive_parameters)
    time_e = time()
    time2 = time_e - time_s
    ref_log_no_comdec, _, _, _ = egraph_label_refinement.get_refined_event_log(event_log, cluster_method="CONNECTED_COMPONENTS", detection_mode_imp_in_loop="postprocessing", egraphs=egraphs_folding, mapping=mapping_folding_semi, map_egraph_ID_to_trace_IDs=map_egraph_ID_to_trace_IDs_folding, map_trace_ID_to_egraph_ID=map_trace_ID_to_egraph_ID_folding, use_adaptive_parameters=use_adaptive_parameters)
    ref_log_no_folding, _, _, _ = egraph_label_refinement.get_refined_event_log(event_log, cluster_method="COMMUNITY_DETECTION", detection_mode_imp_in_loop="postprocessing", egraphs=egraphs, mapping=mapping_semi, map_egraph_ID_to_trace_IDs=map_egraph_ID_to_trace_IDs, map_trace_ID_to_egraph_ID=map_trace_ID_to_egraph_ID, use_adaptive_parameters=use_adaptive_parameters)
    ref_log_no_semi, _, _, _ = egraph_label_refinement.get_refined_event_log(event_log, cluster_method="COMMUNITY_DETECTION", detection_mode_imp_in_loop="postprocessing", egraphs=egraphs_folding, mapping=mapping_folding, map_egraph_ID_to_trace_IDs=map_egraph_ID_to_trace_IDs_folding, map_trace_ID_to_egraph_ID=map_trace_ID_to_egraph_ID_folding, use_adaptive_parameters=use_adaptive_parameters)
    ref_log_vertical, _, _, _ = egraph_label_refinement.get_refined_event_log(event_log, cluster_method="COMMUNITY_DETECTION", detection_mode_imp_in_loop="vertical", egraphs=egraphs_folding, mapping=mapping_folding_semi, map_egraph_ID_to_trace_IDs=map_egraph_ID_to_trace_IDs_folding, map_trace_ID_to_egraph_ID=map_trace_ID_to_egraph_ID_folding, use_adaptive_parameters=use_adaptive_parameters)

    org_model_prec =                    precision_util.get_precision_of_original_model(original_net, original_initial_marking, original_final_marking, event_log, imprecise_labels, original_labels, parameters) #todo test
    precise_refined_log_prec =          precision_util.get_precision_of_precice_log(original_event_log, event_log, imprecise_labels, original_labels, parameters)

    imp_prec =                          precision_util.get_precision(event_log, event_log, imprecise_labels, parameters)


    ref_log_prec =                      precision_util.get_precision(ref_log, event_log, imprecise_labels, parameters)
    xixi_prec =                         precision_util.get_precision(xixi_log, event_log, imprecise_labels, parameters)

    ref_log_comdec_prec =               precision_util.get_precision(ref_log_comdec, event_log, imprecise_labels, parameters)
    ref_log_folding_prec =              precision_util.get_precision(ref_log_folding, event_log, imprecise_labels, parameters)
    ref_log_semi_prec =                 precision_util.get_precision(ref_log_semi, event_log, imprecise_labels, parameters)
    ref_log_no_vertical_prec =          precision_util.get_precision(ref_log_no_vertical, event_log, imprecise_labels, parameters)

    ref_log_all_prec =                  precision_util.get_precision(ref_log_all, event_log, imprecise_labels, parameters)

    ref_log_no_comdec_prec =            precision_util.get_precision(ref_log_no_comdec, event_log, imprecise_labels, parameters)
    ref_log_no_folding_prec =           precision_util.get_precision(ref_log_no_folding, event_log, imprecise_labels, parameters)
    ref_log_no_semi_prec =              precision_util.get_precision(ref_log_no_semi, event_log, imprecise_labels, parameters)
    ref_log_vertical_prec =             precision_util.get_precision(ref_log_vertical, event_log, imprecise_labels, parameters) #no postpro = vetical ref.

    number_of_different_original_labels = precision_util.get_number_of_different_original_labels(event_log)
    #print("number_of_different_original_labels: ", number_of_different_original_labels)

    time_needed_for_all_extensions = time0 + time1 + time2

    end_time = time()
    epoch_time = end_time - start_time
    print("epoch time: ", epoch_time)
    return  org_model_prec, precise_refined_log_prec,\
            imp_prec, xixi_prec, ref_log_prec,\
            ref_log_comdec_prec, ref_log_folding_prec, ref_log_semi_prec, ref_log_no_vertical_prec,\
            ref_log_all_prec,\
            ref_log_no_comdec_prec, ref_log_no_folding_prec, ref_log_no_semi_prec, ref_log_vertical_prec,\
            number_of_different_original_labels, \
            epoch_time,\
            time_needed_for_all_extensions, \
            time_for_greedy_mapping, time_for_semi_greedy_mapping, \
            num_of_new_labels, num_of_new_labels_comdec, num_of_new_labels_folding, num_of_new_labels_semi, num_of_new_labels_no_vertical, \
            mapping_quality, mapping_folding_quality, mapping_semi_quality, mapping_folding_semi_quality








