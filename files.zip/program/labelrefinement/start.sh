log_size=200
batch_size_parameter=30
exp_nr=100

python3 test_main.py $log_size $batch_size_parameter $exp_nr 0 &
python3 test_main.py $log_size $batch_size_parameter $exp_nr 1 &
python3 test_main.py $log_size $batch_size_parameter $exp_nr 2 &
python3 test_main.py $log_size $batch_size_parameter $exp_nr 3 &
python3 test_main.py $log_size $batch_size_parameter $exp_nr 4 &
python3 test_main.py $log_size $batch_size_parameter $exp_nr 5 &
python3 test_main.py $log_size $batch_size_parameter $exp_nr 6 &
python3 test_main.py $log_size $batch_size_parameter $exp_nr 7 &
python3 test_main.py $log_size $batch_size_parameter $exp_nr 8 &
python3 test_main.py $log_size $batch_size_parameter $exp_nr 9 &
python3 test_main.py $log_size $batch_size_parameter $exp_nr 10 &
python3 test_main.py $log_size $batch_size_parameter $exp_nr 11 &
python3 test_main.py $log_size $batch_size_parameter $exp_nr 12 &
python3 test_main.py $log_size $batch_size_parameter $exp_nr 13 &
python3 test_main.py $log_size $batch_size_parameter $exp_nr 14 &
python3 test_main.py $log_size $batch_size_parameter $exp_nr 15 &
python3 test_main.py $log_size $batch_size_parameter $exp_nr 16 &
python3 test_main.py $log_size $batch_size_parameter $exp_nr 17 &
python3 test_main.py $log_size $batch_size_parameter $exp_nr 18 &
python3 test_main.py $log_size $batch_size_parameter $exp_nr 19 &